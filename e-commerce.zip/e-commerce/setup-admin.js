/**
 * Run this ONCE after setting up the database to create/update the admin user.
 * Usage: node setup-admin.js
 */
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./config/database');

async function setup() {
  console.log('Setting up admin user...');
  const hash = await bcrypt.hash('pacifique', 10);
  await db.query(
    `INSERT INTO users (full_name, email, username, password, role) 
     VALUES ('Batege Pacifique', 'pacifiquebatege@gmail.com', 'anoited', ?, 'admin')
     ON DUPLICATE KEY UPDATE password = ?, role = 'admin'`,
    [hash, hash]
  );
  console.log('✅ Admin user created!');
  console.log('   Username: anoited');
  console.log('   Password: pacifique');
  process.exit(0);
}

setup().catch(err => { console.error(err); process.exit(1); });
