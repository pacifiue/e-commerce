require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Create uploads directory
if (!fs.existsSync('public/uploads')) fs.mkdirSync('public/uploads', { recursive: true });

// View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'shopvibe_secret_2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 } // 24 hours
}));

// Global locals
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// Routes
const authRoutes = require('./routes/auth');
const shopRoutes = require('./routes/shop');
const adminRoutes = require('./routes/admin');

app.use('/', authRoutes);
app.use('/', shopRoutes);
app.use('/admin', adminRoutes);

// 404
app.use((req, res) => {
  res.status(404).render('404', { title: '404 - Page Not Found', user: req.session.user || null });
});

app.listen(PORT, () => {
  console.log(`\n🚀 ShopVibe is running on http://localhost:${PORT}`);
  console.log(`📦 Admin: http://localhost:${PORT}/login`);
  console.log(`   Username: admin | Password: passadmin\n`);
});
