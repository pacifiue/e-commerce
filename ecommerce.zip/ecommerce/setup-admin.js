/**
 * Run this ONCE after setting up the database to create/update the admin user.
 * Usage: node setup-admin.js
 */
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./config/database');

async function setup() {
  console.log('Setting up admin user...');
  const hash = await bcrypt.hash('passadmin', 10);
  await db.query(
    `INSERT INTO users (full_name, email, username, password, role) 
     VALUES ('Administrator', 'admin@shopvibe.com', 'admin', ?, 'admin')
     ON DUPLICATE KEY UPDATE password = ?, role = 'admin'`,
    [hash, hash]
  );
  console.log('✅ Admin user created!');
  console.log('   Username: admin');
  console.log('   Password: passadmin');
  process.exit(0);
}

setup().catch(err => { console.error(err); process.exit(1); });
