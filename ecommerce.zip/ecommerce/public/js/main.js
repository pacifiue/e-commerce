// ============================================
// ShopVibe - Main JS
// ============================================

// Toast notifications
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container') || (() => {
    const c = document.createElement('div');
    c.id = 'toast-container';
    c.className = 'toast-container';
    document.body.appendChild(c);
    return c;
  })();
  
  const toast = document.createElement('div');
  toast.className = `toast ${type === 'error' ? 'error' : ''}`;
  toast.innerHTML = `<span>${type === 'success' ? '✅' : '❌'}</span><span>${message}</span>`;
  container.appendChild(toast);
  
  setTimeout(() => { toast.style.animation = 'slideIn 0.3s reverse'; setTimeout(() => toast.remove(), 300); }, 3000);
}

// Add to Cart
async function addToCart(productId, qty = 1) {
  try {
    const res = await fetch('/cart/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product_id: productId, quantity: qty })
    });
    const data = await res.json();
    if (data.success) {
      showToast('Added to cart! 🛒');
      updateCartCount();
    } else {
      showToast(data.message || 'Error', 'error');
    }
  } catch (e) {
    showToast('Please login to add items', 'error');
    setTimeout(() => window.location.href = '/login', 1000);
  }
}

// Update cart count in navbar
async function updateCartCount() {
  const badge = document.querySelector('.cart-count');
  if (!badge) return;
  try {
    const res = await fetch('/cart/count');
    const data = await res.json();
    badge.textContent = data.count || 0;
    badge.style.display = data.count > 0 ? 'flex' : 'none';
  } catch (e) {}
}

// Cart quantity update
async function updateCartQty(cartId, qty) {
  const res = await fetch('/cart/update', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cart_id: cartId, quantity: qty })
  });
  const data = await res.json();
  if (data.success) location.reload();
}

// Remove from cart
async function removeFromCart(cartId) {
  if (!confirm('Remove this item?')) return;
  const res = await fetch('/cart/remove', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cart_id: cartId })
  });
  const data = await res.json();
  if (data.success) location.reload();
}

// Modal helpers
function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.add('open'); document.body.style.overflow = 'hidden'; }
}

function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.remove('open'); document.body.style.overflow = ''; }
}

// Close modal on overlay click
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// Close modal on Escape
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => {
      m.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
});

// Admin: confirm delete
function confirmDelete(formId, msg = 'Are you sure you want to delete this?') {
  if (confirm(msg)) {
    document.getElementById(formId).submit();
  }
}

// Qty controls
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.qty-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.parentElement.querySelector('.qty-input');
      const current = parseInt(input.value) || 1;
      const delta = this.dataset.delta === '-1' ? -1 : 1;
      const min = parseInt(input.min) || 1;
      const max = parseInt(input.max) || 999;
      input.value = Math.max(min, Math.min(max, current + delta));
    });
  });

  // Auto-dismiss alerts
  setTimeout(() => {
    document.querySelectorAll('.auto-dismiss').forEach(el => {
      el.style.transition = 'opacity 0.5s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 500);
    });
  }, 4000);
});

// Admin chart rendering
function renderBarChart(canvasId, labels, data, color = '#e94560') {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const maxVal = Math.max(...data, 1);
  const cw = canvas.width, ch = canvas.height;
  const barW = (cw - 40) / data.length - 8;
  
  ctx.clearRect(0, 0, cw, ch);
  
  data.forEach((val, i) => {
    const x = 20 + i * (barW + 8);
    const h = ((val / maxVal) * (ch - 40));
    const y = ch - 20 - h;
    
    const grad = ctx.createLinearGradient(0, y, 0, ch - 20);
    grad.addColorStop(0, color);
    grad.addColorStop(1, color + '40');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(x, y, barW, h, [4, 4, 0, 0]);
    ctx.fill();
    
    ctx.fillStyle = '#718096';
    ctx.font = '10px DM Sans';
    ctx.textAlign = 'center';
    ctx.fillText(labels[i] || '', x + barW/2, ch - 4);
  });
}
