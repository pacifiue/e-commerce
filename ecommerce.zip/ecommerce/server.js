require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Create uploads directory
if (!fs.existsSync('public/uploads')) fs.mkdirSync('public/uploads', { recursive: true });

// View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'shopvibe_secret_2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 } // 24 hours
}));

// Global locals
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// ── IMAGE PROXY ──
// Handles: direct image URLs + Pinterest pin page URLs
// Usage: /img-proxy?url=https://www.pinterest.com/pin/123/
//    or: /img-proxy?url=https://i.pinimg.com/originals/xx.jpg
app.get('/img-proxy', async (req, res) => {
  const targetUrl = (req.query.url || '').trim();
  if (!targetUrl) return res.status(400).send('Missing url param');
  if (!/^https?:\/\//i.test(targetUrl)) return res.status(400).send('Invalid URL');

  const https = require('https');
  const http  = require('http');

  function fetchUrl(url, redirectCount) {
    if (redirectCount > 5) return res.status(508).send('Too many redirects');
    const client = url.startsWith('https') ? https : http;
    const reqOpts = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept':     'text/html,image/webp,image/apng,image/*,*/*;q=0.9',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer':    'https://www.pinterest.com/',
        'sec-fetch-dest': 'image',
      },
      timeout: 12000,
    };
    const proxyReq = client.get(url, reqOpts, (imgRes) => {
      // Follow redirects
      if ([301,302,303,307,308].includes(imgRes.statusCode) && imgRes.headers.location) {
        const next = imgRes.headers.location.startsWith('http')
          ? imgRes.headers.location
          : new URL(imgRes.headers.location, url).href;
        imgRes.resume();
        return fetchUrl(next, redirectCount + 1);
      }

      const ct = imgRes.headers['content-type'] || '';

      // If it's a Pinterest pin PAGE (not an image), scrape the image URL from HTML
      if (ct.includes('text/html')) {
        let html = '';
        imgRes.setEncoding('utf8');
        imgRes.on('data', chunk => { html += chunk; if (html.length > 150000) imgRes.destroy(); });
        imgRes.on('end', () => {
          // Pinterest stores the main image in meta og:image
          const ogMatch = html.match(/<meta[^>]+property="og:image"[^>]+content="([^"]+)"/i)
                       || html.match(/<meta[^>]+content="([^"]+)"[^>]+property="og:image"/i);
          if (ogMatch && ogMatch[1]) {
            const imgUrl = ogMatch[1].replace(/&amp;/g, '&');
            return fetchUrl(imgUrl, redirectCount + 1);
          }
          // Fallback: look for pinimg.com URLs in the HTML
          const pinimgMatch = html.match(/https:\/\/i\.pinimg\.com\/[^"'\s]+\.(?:jpg|jpeg|png|webp)/i);
          if (pinimgMatch) {
            return fetchUrl(pinimgMatch[0], redirectCount + 1);
          }
          return res.status(422).send('Could not extract image from Pinterest page');
        });
        imgRes.on('error', () => res.status(502).send('HTML read error'));
        return;
      }

      // It's a direct image
      if (imgRes.statusCode !== 200) {
        return res.status(imgRes.statusCode).send('Upstream error ' + imgRes.statusCode);
      }
      res.setHeader('Content-Type', ct || 'image/jpeg');
      res.setHeader('Cache-Control', 'public, max-age=604800'); // 7 days
      res.setHeader('Access-Control-Allow-Origin', '*');
      imgRes.pipe(res);
    });
    proxyReq.on('error', (e) => { if (!res.headersSent) res.status(502).send('Proxy error: ' + e.message); });
    proxyReq.on('timeout', () => { proxyReq.destroy(); if (!res.headersSent) res.status(504).send('Timeout'); });
  }

  try {
    fetchUrl(targetUrl, 0);
  } catch(err) {
    if (!res.headersSent) res.status(500).send('Server error');
  }
});

// Routes
const authRoutes = require('./routes/auth');
const shopRoutes = require('./routes/shop');
const adminRoutes = require('./routes/admin');

app.use('/', authRoutes);
app.use('/', shopRoutes);
app.use('/admin', adminRoutes);

// 404
app.use((req, res) => {
  res.status(404).render('404', { title: '404 — MTRPS Furniture Ltd', user: req.session.user || null });
});

app.listen(PORT, () => {
  console.log(`\n🪑  MTRPS Furniture Ltd is running on http://localhost:${PORT}`);
  console.log(`🔑  Admin panel: http://localhost:${PORT}/login`);
  console.log(`    Username: admin  |  Password: passadmin\n`);
});
