-- ============================================
-- E-Commerce Platform - Database Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS ecommerce_db;
USE ecommerce_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  address TEXT,
  role ENUM('customer', 'admin') DEFAULT 'customer',
  avatar VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Categories Table
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products Table
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  stock INT DEFAULT 0,
  category_id INT,
  image VARCHAR(255),
  featured BOOLEAN DEFAULT FALSE,
  status ENUM('active', 'inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Orders Table
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  status ENUM('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
  payment_method VARCHAR(50) DEFAULT 'cash_on_delivery',
  shipping_address TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order Items Table
CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Cart Table
CREATE TABLE IF NOT EXISTS cart (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Advertisements Table
CREATE TABLE IF NOT EXISTS advertisements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  image VARCHAR(255),
  link VARCHAR(255),
  position ENUM('hero', 'banner', 'sidebar', 'popup') DEFAULT 'banner',
  status ENUM('active', 'inactive') DEFAULT 'active',
  start_date DATE,
  end_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Default Admin User (password: passadmin)
-- ============================================
INSERT INTO users (full_name, email, username, password, role) 
VALUES ('Administrator', 'admin@shopvibe.com', 'admin', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'admin')
ON DUPLICATE KEY UPDATE role='admin';
-- NOTE: Replace the hashed password above by running: node -e "const b=require('bcryptjs');console.log(b.hashSync('passadmin',10))"

-- Sample Categories
INSERT INTO categories (name, description) VALUES
('Electronics', 'Latest gadgets and electronic devices'),
('Fashion', 'Trendy clothing and accessories'),
('Home & Living', 'Furniture and home decor'),
('Sports', 'Sports equipment and activewear'),
('Beauty', 'Skincare and beauty products')
ON DUPLICATE KEY UPDATE name=name;

-- Sample Products
INSERT INTO products (name, description, price, original_price, stock, category_id, featured, image) VALUES
('Wireless Headphones Pro', 'Premium noise-cancelling wireless headphones with 30hr battery', 89.99, 129.99, 50, 1, TRUE, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400'),
('Smart Watch Series X', 'Advanced fitness tracker with health monitoring features', 249.99, 299.99, 30, 1, TRUE, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400'),
('Premium Sneakers', 'Lightweight running shoes with advanced cushioning', 119.99, 149.99, 100, 2, TRUE, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400'),
('Leather Jacket', 'Genuine leather biker jacket - timeless style', 199.99, 249.99, 25, 2, FALSE, 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400'),
('Minimalist Desk Lamp', 'LED desk lamp with adjustable brightness and color', 49.99, 69.99, 75, 3, TRUE, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400'),
('Yoga Mat Premium', 'Non-slip eco-friendly yoga mat with carrying strap', 39.99, 55.99, 60, 4, FALSE, 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400'),
('Facial Serum Gold', 'Anti-aging vitamin C serum for radiant skin', 59.99, 79.99, 40, 5, TRUE, 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400'),
('Bluetooth Speaker', 'Portable waterproof speaker with 360 sound', 79.99, 99.99, 45, 1, FALSE, 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400')
ON DUPLICATE KEY UPDATE name=name;

-- Sample Advertisements
INSERT INTO advertisements (title, description, position, status) VALUES
('Summer Sale - Up to 50% Off!', 'Shop the biggest sale of the year', 'hero', 'active'),
('Free Shipping on Orders Over $50', 'Limited time offer', 'banner', 'active'),
('New Collection Arrived', 'Explore our latest products', 'sidebar', 'active')
ON DUPLICATE KEY UPDATE title=title;
