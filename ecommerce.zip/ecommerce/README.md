# 🛍️ ShopVibe - Professional E-Commerce Platform

A full-stack e-commerce + advertising platform built with **Node.js**, **Express**, **MySQL**, and **EJS**.

## ✨ Features

### Customer Side
- 🏠 Landing page with featured products, categories & ads
- 🔐 Register/Login with secure bcrypt passwords  
- 🛒 Shopping cart (add/remove/update)
- 📦 Place orders with shipping details
- 📋 View order history & status
- 👤 Profile management

### Admin Dashboard (`/admin`)
- 📊 Dashboard with revenue charts, order stats, top products
- 🏷️ Product management (add/edit/delete with images)
- 📦 Order management (view, update status)
- 👥 Customer management (view profiles, order history)
- 🗂️ Category management
- 📢 Advertising management (hero, banner, sidebar, popup ads)

## 🚀 Setup Instructions

### 1. Prerequisites
- Node.js v18+
- MySQL 8.0+

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment
```bash
cp .env.example .env
# Edit .env with your MySQL credentials
```

### 4. Create Database
```bash
mysql -u root -p < database.sql
```

### 5. Set Up Admin User
```bash
node setup-admin.js
```

### 6. Start the Server
```bash
npm start
# or for development:
npm run dev
```

Visit: `http://localhost:3000`

## 🔐 Login Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `passadmin` |
| Customer | Register at `/register` | — |

## 📁 Project Structure

```
shopvibe/
├── config/          # Database config
├── middleware/      # Auth middleware
├── public/          # Static files (CSS, JS, uploads)
│   ├── css/
│   │   ├── style.css     # Customer frontend
│   │   └── admin.css     # Admin dashboard
├── routes/          # Express routes
│   ├── auth.js      # Login/Register/Logout
│   ├── shop.js      # Customer shop pages
│   └── admin.js     # Admin dashboard
├── views/           # EJS templates
│   ├── home.ejs     # Landing page
│   ├── auth/        # Login/Register
│   ├── shop/        # Customer pages
│   └── admin/       # Admin pages
├── database.sql     # MySQL schema + seed data
├── server.js        # Express app entry point
└── setup-admin.js   # One-time admin setup
```
