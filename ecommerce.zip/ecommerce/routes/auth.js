const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../config/database');
const { redirectIfLoggedIn } = require('../middleware/auth');

// GET Login
router.get('/login', redirectIfLoggedIn, (req, res) => {
  res.render('auth/login', { 
    title: 'Login - ShopVibe',
    error: req.session.error || null,
    success: req.session.success || null
  });
  delete req.session.error;
  delete req.session.success;
});

// POST Login
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [rows] = await db.query('SELECT * FROM users WHERE username = ? OR email = ?', [username, username]);
    if (!rows.length) {
      req.session.error = 'Invalid username or password';
      return res.redirect('/login');
    }
    const user = rows[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      req.session.error = 'Invalid username or password';
      return res.redirect('/login');
    }
    req.session.user = {
      id: user.id,
      full_name: user.full_name,
      email: user.email,
      username: user.username,
      role: user.role,
      avatar: user.avatar
    };
    if (user.role === 'admin') return res.redirect('/admin');
    res.redirect('/shop');
  } catch (err) {
    console.error(err);
    req.session.error = 'Server error. Please try again.';
    res.redirect('/login');
  }
});

// GET Register
router.get('/register', redirectIfLoggedIn, (req, res) => {
  res.render('auth/register', { 
    title: 'Register - ShopVibe',
    error: req.session.error || null
  });
  delete req.session.error;
});

// POST Register
router.post('/register', async (req, res) => {
  const { full_name, email, username, password, confirm_password, phone } = req.body;
  try {
    if (password !== confirm_password) {
      req.session.error = 'Passwords do not match';
      return res.redirect('/register');
    }
    if (password.length < 6) {
      req.session.error = 'Password must be at least 6 characters';
      return res.redirect('/register');
    }
    const [existing] = await db.query('SELECT id FROM users WHERE email = ? OR username = ?', [email, username]);
    if (existing.length) {
      req.session.error = 'Email or username already taken';
      return res.redirect('/register');
    }
    const hashed = await bcrypt.hash(password, 10);
    await db.query(
      'INSERT INTO users (full_name, email, username, password, phone, role) VALUES (?, ?, ?, ?, ?, ?)',
      [full_name, email, username, hashed, phone || null, 'customer']
    );
    req.session.success = 'Account created! Please login.';
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    req.session.error = 'Registration failed. Please try again.';
    res.redirect('/register');
  }
});

// GET Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
