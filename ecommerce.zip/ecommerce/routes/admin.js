const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { requireAdmin } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'public/uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

// ---- DASHBOARD ----
router.get('/', requireAdmin, async (req, res) => {
  try {
    const [[{ total_users }]] = await db.query('SELECT COUNT(*) as total_users FROM users WHERE role="customer"');
    const [[{ total_orders }]] = await db.query('SELECT COUNT(*) as total_orders FROM orders');
    const [[{ total_revenue }]] = await db.query('SELECT IFNULL(SUM(total_amount),0) as total_revenue FROM orders WHERE status != "cancelled"');
    const [[{ total_products }]] = await db.query('SELECT COUNT(*) as total_products FROM products');
    const [recent_orders] = await db.query('SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 10');
    const [top_products] = await db.query('SELECT p.name, p.price, p.image, SUM(oi.quantity) as sold FROM order_items oi JOIN products p ON oi.product_id = p.id GROUP BY p.id ORDER BY sold DESC LIMIT 5');
    const [monthly_revenue] = await db.query('SELECT DATE_FORMAT(created_at, "%b") as month, SUM(total_amount) as revenue FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) GROUP BY month ORDER BY created_at ASC');
    const [order_stats] = await db.query('SELECT status, COUNT(*) as count FROM orders GROUP BY status');

    res.render('admin/dashboard', { 
      title: 'Admin Dashboard - ShopVibe',
      stats: { total_users, total_orders, total_revenue, total_products },
      recent_orders, top_products, monthly_revenue, order_stats,
      user: req.session.user,
      success: req.session.success || null,
      error: req.session.error || null
    });
    delete req.session.success; delete req.session.error;
  } catch (err) {
    console.error(err);
    res.render('admin/dashboard', { title: 'Admin Dashboard', stats: {}, recent_orders: [], top_products: [], monthly_revenue: [], order_stats: [], user: req.session.user, success: null, error: err.message });
  }
});

// ---- PRODUCTS ----
router.get('/products', requireAdmin, async (req, res) => {
  const [products] = await db.query('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC');
  const [categories] = await db.query('SELECT * FROM categories');
  const flashSuccess = req.session.success || null;
  const flashError   = req.session.error   || null;
  delete req.session.success;
  delete req.session.error;
  res.render('admin/products', { title: 'Products — MTRPS Furniture', products, categories, user: req.session.user, success: flashSuccess, error: flashError });
});

// Helper: always proxy external image URLs to avoid CORS / hotlink blocks
// This covers Pinterest pin pages, pinimg CDN, Instagram, Twitter CDN, etc.
function normalizeImageUrl(rawUrl) {
  if (!rawUrl || !rawUrl.trim()) return null;
  const url = rawUrl.trim();
  // If it's already our proxy URL, leave it
  if (url.startsWith('/img-proxy')) return url;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    // Always proxy external images — avoids all hotlink/CORS issues
    if (host !== 'localhost' && host !== '127.0.0.1') {
      return '/img-proxy?url=' + encodeURIComponent(url);
    }
  } catch (e) {}
  return url;
}

router.post('/products/add', requireAdmin, async (req, res) => {
  const { name, description, price, original_price, stock, category_id, featured, status, image_url } = req.body;
  try {
    const finalImage = normalizeImageUrl(image_url);
    await db.query('INSERT INTO products (name, description, price, original_price, stock, category_id, featured, status, image) VALUES (?,?,?,?,?,?,?,?,?)',
      [name, description, price, original_price || null, stock || 0, category_id || null, featured ? 1 : 0, status || 'active', finalImage]);
    req.session.success = 'Product added successfully!';
  } catch (err) {
    req.session.error = 'Failed to add product: ' + err.message;
  }
  res.redirect('/admin/products');
});

router.post('/products/edit/:id', requireAdmin, async (req, res) => {
  const { name, description, price, original_price, stock, category_id, featured, status, image_url } = req.body;
  try {
    const finalImage = normalizeImageUrl(image_url);
    await db.query('UPDATE products SET name=?, description=?, price=?, original_price=?, stock=?, category_id=?, featured=?, status=?, image=? WHERE id=?',
      [name, description, price, original_price || null, stock || 0, category_id || null, featured ? 1 : 0, status || 'active', finalImage, req.params.id]);
    req.session.success = 'Product updated!';
  } catch (err) {
    req.session.error = 'Update failed: ' + err.message;
  }
  res.redirect('/admin/products');
});

router.post('/products/delete/:id', requireAdmin, async (req, res) => {
  const productId = req.params.id;
  try {
    // Remove FK-linked rows first to avoid constraint errors
    await db.query('DELETE FROM cart WHERE product_id = ?', [productId]);
    await db.query('DELETE FROM order_items WHERE product_id = ?', [productId]);
    await db.query('DELETE FROM products WHERE id = ?', [productId]);
    req.session.success = 'Product deleted successfully.';
  } catch (err) {
    console.error('Delete product error:', err.message);
    req.session.error = 'Delete failed: ' + err.message;
  }
  res.redirect('/admin/products');
});

// ---- ORDERS ----
router.get('/orders', requireAdmin, async (req, res) => {
  const { status } = req.query;
  let query = 'SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON o.user_id = u.id';
  let params = [];
  if (status) { query += ' WHERE o.status = ?'; params.push(status); }
  query += ' ORDER BY o.created_at DESC';
  const [orders] = await db.query(query, params);
  res.render('admin/orders', { title: 'Orders - Admin', orders, user: req.session.user, filterStatus: status || '', success: req.session.success || null });
  delete req.session.success;
});

router.get('/orders/:id', requireAdmin, async (req, res) => {
  const [orders] = await db.query('SELECT o.*, u.full_name, u.email, u.phone FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?', [req.params.id]);
  if (!orders.length) return res.redirect('/admin/orders');
  const [items] = await db.query('SELECT oi.*, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?', [req.params.id]);
  res.render('admin/order-detail', { title: 'Order #' + req.params.id, order: orders[0], items, user: req.session.user });
});

router.post('/orders/status/:id', requireAdmin, async (req, res) => {
  await db.query('UPDATE orders SET status = ? WHERE id = ?', [req.body.status, req.params.id]);
  req.session.success = 'Order status updated!';
  res.redirect('/admin/orders');
});

// ---- CUSTOMERS ----
router.get('/customers', requireAdmin, async (req, res) => {
  const [customers] = await db.query(
    'SELECT u.*, COUNT(o.id) as order_count, IFNULL(SUM(o.total_amount),0) as total_spent FROM users u LEFT JOIN orders o ON u.id = o.user_id WHERE u.role = "customer" GROUP BY u.id ORDER BY u.created_at DESC'
  );
  res.render('admin/customers', { title: 'Customers - Admin', customers, user: req.session.user });
});

router.get('/customers/:id', requireAdmin, async (req, res) => {
  const [users] = await db.query('SELECT * FROM users WHERE id = ?', [req.params.id]);
  if (!users.length) return res.redirect('/admin/customers');
  const [orders] = await db.query('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC', [req.params.id]);
  res.render('admin/customer-detail', { title: 'Customer - Admin', customer: users[0], orders, user: req.session.user });
});

// ---- CATEGORIES ----
router.get('/categories', requireAdmin, async (req, res) => {
  const [categories] = await db.query('SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id');
  res.render('admin/categories', { title: 'Categories - Admin', categories, user: req.session.user, success: req.session.success || null });
  delete req.session.success;
});

router.post('/categories/add', requireAdmin, async (req, res) => {
  const { name, description } = req.body;
  await db.query('INSERT INTO categories (name, description) VALUES (?, ?)', [name, description]);
  req.session.success = 'Category added!';
  res.redirect('/admin/categories');
});

router.post('/categories/delete/:id', requireAdmin, async (req, res) => {
  await db.query('DELETE FROM categories WHERE id = ?', [req.params.id]);
  req.session.success = 'Category deleted.';
  res.redirect('/admin/categories');
});

// ---- ADS ----
router.get('/ads', requireAdmin, async (req, res) => {
  const [ads] = await db.query('SELECT * FROM advertisements ORDER BY created_at DESC');
  res.render('admin/ads', { title: 'Advertisements - Admin', ads, user: req.session.user, success: req.session.success || null });
  delete req.session.success;
});

router.post('/ads/add', requireAdmin, async (req, res) => {
  const { title, description, image, link, position, status, start_date, end_date } = req.body;
  await db.query('INSERT INTO advertisements (title, description, image, link, position, status, start_date, end_date) VALUES (?,?,?,?,?,?,?,?)',
    [title, description, image || null, link || null, position, status || 'active', start_date || null, end_date || null]);
  req.session.success = 'Ad created!';
  res.redirect('/admin/ads');
});

router.post('/ads/toggle/:id', requireAdmin, async (req, res) => {
  await db.query('UPDATE advertisements SET status = IF(status="active","inactive","active") WHERE id = ?', [req.params.id]);
  res.redirect('/admin/ads');
});

router.post('/ads/delete/:id', requireAdmin, async (req, res) => {
  await db.query('DELETE FROM advertisements WHERE id = ?', [req.params.id]);
  req.session.success = 'Ad deleted.';
  res.redirect('/admin/ads');
});

module.exports = router;
