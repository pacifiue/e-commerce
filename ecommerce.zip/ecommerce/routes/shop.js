const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { requireLogin } = require('../middleware/auth');

// GET Home / Landing
router.get('/', async (req, res) => {
  try {
    const [featured] = await db.query('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.featured = TRUE AND p.status = "active" LIMIT 8');
    const [categories] = await db.query('SELECT * FROM categories LIMIT 6');
    const [ads] = await db.query('SELECT * FROM advertisements WHERE status = "active"');
    const [allProducts] = await db.query('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.status = "active" LIMIT 12');
    res.render('home', { 
      title: 'ShopVibe - Premium E-Commerce',
      featured, categories, ads, allProducts,
      user: req.session.user || null
    });
  } catch (err) {
    console.error(err);
    res.render('home', { title: 'ShopVibe', featured: [], categories: [], ads: [], allProducts: [], user: null });
  }
});

// GET Shop
router.get('/shop', requireLogin, async (req, res) => {
  try {
    const { category, search, sort } = req.query;
    let query = 'SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.status = "active"';
    let params = [];
    if (category) { query += ' AND p.category_id = ?'; params.push(category); }
    if (search) { query += ' AND (p.name LIKE ? OR p.description LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    if (sort === 'price_asc') query += ' ORDER BY p.price ASC';
    else if (sort === 'price_desc') query += ' ORDER BY p.price DESC';
    else query += ' ORDER BY p.created_at DESC';

    const [products] = await db.query(query, params);
    const [categories] = await db.query('SELECT * FROM categories');
    const [cartItems] = await db.query('SELECT SUM(quantity) as total FROM cart WHERE user_id = ?', [req.session.user.id]);
    
    res.render('shop/index', { 
      title: 'Shop - ShopVibe',
      products, categories, 
      cartCount: cartItems[0].total || 0,
      currentCategory: category || '',
      search: search || '',
      sort: sort || '',
      user: req.session.user
    });
  } catch (err) {
    console.error(err);
    res.redirect('/');
  }
});

// GET Product Detail
router.get('/product/:id', requireLogin, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ?', [req.params.id]);
    if (!rows.length) return res.redirect('/shop');
    const [related] = await db.query('SELECT * FROM products WHERE category_id = ? AND id != ? LIMIT 4', [rows[0].category_id, req.params.id]);
    const [cartItems] = await db.query('SELECT SUM(quantity) as total FROM cart WHERE user_id = ?', [req.session.user.id]);
    res.render('shop/product', { 
      title: rows[0].name + ' - ShopVibe',
      product: rows[0], related,
      cartCount: cartItems[0].total || 0,
      user: req.session.user
    });
  } catch (err) {
    console.error(err);
    res.redirect('/shop');
  }
});

// POST Add to Cart
router.post('/cart/add', requireLogin, async (req, res) => {
  const { product_id, quantity } = req.body;
  try {
    const [existing] = await db.query('SELECT * FROM cart WHERE user_id = ? AND product_id = ?', [req.session.user.id, product_id]);
    if (existing.length) {
      await db.query('UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?', [quantity || 1, req.session.user.id, product_id]);
    } else {
      await db.query('INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)', [req.session.user.id, product_id, quantity || 1]);
    }
    res.json({ success: true, message: 'Added to cart' });
  } catch (err) {
    res.json({ success: false, message: 'Error adding to cart' });
  }
});

// GET Cart
router.get('/cart', requireLogin, async (req, res) => {
  try {
    const [items] = await db.query(
      'SELECT c.id, c.quantity, p.name, p.price, p.image, p.id as product_id FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?',
      [req.session.user.id]
    );
    const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    res.render('shop/cart', { title: 'Cart - ShopVibe', items, total, user: req.session.user, cartCount: items.reduce((s,i) => s+i.quantity, 0) });
  } catch (err) {
    res.redirect('/shop');
  }
});

// POST Update Cart
router.post('/cart/update', requireLogin, async (req, res) => {
  const { cart_id, quantity } = req.body;
  try {
    if (parseInt(quantity) <= 0) {
      await db.query('DELETE FROM cart WHERE id = ? AND user_id = ?', [cart_id, req.session.user.id]);
    } else {
      await db.query('UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?', [quantity, cart_id, req.session.user.id]);
    }
    res.json({ success: true });
  } catch (err) {
    res.json({ success: false });
  }
});

// POST Remove from Cart
router.post('/cart/remove', requireLogin, async (req, res) => {
  try {
    await db.query('DELETE FROM cart WHERE id = ? AND user_id = ?', [req.body.cart_id, req.session.user.id]);
    res.json({ success: true });
  } catch (err) {
    res.json({ success: false });
  }
});

// GET Checkout
router.get('/checkout', requireLogin, async (req, res) => {
  try {
    const [items] = await db.query(
      'SELECT c.id, c.quantity, p.name, p.price, p.image, p.id as product_id, p.stock FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?',
      [req.session.user.id]
    );
    if (!items.length) return res.redirect('/cart');
    const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    res.render('shop/checkout', { title: 'Checkout - ShopVibe', items, total, user: req.session.user, cartCount: items.length });
  } catch (err) {
    res.redirect('/cart');
  }
});

// POST Place Order
router.post('/order/place', requireLogin, async (req, res) => {
  const { shipping_address, payment_method, notes } = req.body;
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [items] = await conn.query(
      'SELECT c.quantity, p.price, p.id as product_id, p.stock FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?',
      [req.session.user.id]
    );
    if (!items.length) { await conn.rollback(); conn.release(); return res.redirect('/cart'); }
    const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const [order] = await conn.query(
      'INSERT INTO orders (user_id, total_amount, shipping_address, payment_method, notes) VALUES (?, ?, ?, ?, ?)',
      [req.session.user.id, total, shipping_address, payment_method || 'cash_on_delivery', notes || '']
    );
    for (const item of items) {
      await conn.query('INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)',
        [order.insertId, item.product_id, item.quantity, item.price, item.price * item.quantity]);
      await conn.query('UPDATE products SET stock = stock - ? WHERE id = ?', [item.quantity, item.product_id]);
    }
    await conn.query('DELETE FROM cart WHERE user_id = ?', [req.session.user.id]);
    await conn.commit();
    conn.release();
    res.redirect('/orders?success=1&order_id=' + order.insertId);
  } catch (err) {
    await conn.rollback();
    conn.release();
    console.error(err);
    res.redirect('/checkout');
  }
});

// GET Orders
router.get('/orders', requireLogin, async (req, res) => {
  try {
    const [orders] = await db.query(
      'SELECT o.*, COUNT(oi.id) as item_count FROM orders o LEFT JOIN order_items oi ON o.id = oi.order_id WHERE o.user_id = ? GROUP BY o.id ORDER BY o.created_at DESC',
      [req.session.user.id]
    );
    res.render('shop/orders', { 
      title: 'My Orders - ShopVibe', 
      orders, 
      user: req.session.user,
      success: req.query.success,
      order_id: req.query.order_id,
      cartCount: 0
    });
  } catch (err) {
    res.redirect('/shop');
  }
});

// GET Order Detail
router.get('/orders/:id', requireLogin, async (req, res) => {
  try {
    const [orders] = await db.query('SELECT * FROM orders WHERE id = ? AND user_id = ?', [req.params.id, req.session.user.id]);
    if (!orders.length) return res.redirect('/orders');
    const [items] = await db.query(
      'SELECT oi.*, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?',
      [req.params.id]
    );
    res.render('shop/order-detail', { title: 'Order #' + req.params.id, order: orders[0], items, user: req.session.user, cartCount: 0 });
  } catch (err) {
    res.redirect('/orders');
  }
});

// GET Profile
router.get('/profile', requireLogin, async (req, res) => {
  try {
    const [users] = await db.query('SELECT * FROM users WHERE id = ?', [req.session.user.id]);
    const [orders] = await db.query('SELECT COUNT(*) as count FROM orders WHERE user_id = ?', [req.session.user.id]);
    res.render('shop/profile', { title: 'Profile - ShopVibe', profile: users[0], orderCount: orders[0].count, user: req.session.user, cartCount: 0 });
  } catch (err) {
    res.redirect('/shop');
  }
});

module.exports = router;
