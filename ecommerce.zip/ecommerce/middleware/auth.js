// Middleware: Require login
function requireLogin(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }
  req.session.returnTo = req.originalUrl;
  res.redirect('/login');
}

// Middleware: Require admin
function requireAdmin(req, res, next) {
  if (req.session && req.session.user && req.session.user.role === 'admin') {
    return next();
  }
  res.redirect('/login');
}

// Middleware: Redirect if logged in
function redirectIfLoggedIn(req, res, next) {
  if (req.session && req.session.user) {
    if (req.session.user.role === 'admin') return res.redirect('/admin');
    return res.redirect('/shop');
  }
  next();
}

module.exports = { requireLogin, requireAdmin, redirectIfLoggedIn };
